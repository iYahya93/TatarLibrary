package com.example.tatarlibrary
import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
class PlaybackService:MediaSessionService(){
private lateinit var player:ExoPlayer
private var session:MediaSession?=null
override fun onCreate(){super.onCreate();player=ExoPlayer.Builder(this).setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(),true).build();val pi=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);session=MediaSession.Builder(this,player).setSessionActivity(pi).build()}
override fun onGetSession(c:MediaSession.ControllerInfo)=session
override fun onDestroy(){session?.release();player.release();super.onDestroy()}
}