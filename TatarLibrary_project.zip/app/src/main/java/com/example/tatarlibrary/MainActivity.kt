package com.example.tatarlibrary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

class MainActivity:ComponentActivity(){
    private var player:ExoPlayer?=null
    override fun onCreate(b:Bundle?){super.onCreate(b); player=ExoPlayer.Builder(this).build(); setContent{App(player!!)}}
    override fun onDestroy(){player?.release();super.onDestroy()}
}
@Composable fun App(player:ExoPlayer){
    var tab by remember{mutableStateOf(0)}
    var group by remember{mutableStateOf<String?>(null)}
    var playing by remember{mutableStateOf<AudioItem?>(null)}
    MaterialTheme(colorScheme=darkColorScheme()){
        if(group!=null) Detail(group!!,{group=null},{e-> play(player,e);playing=e})
        else Scaffold(bottomBar={
            NavigationBar{listOf("الرئيسية","القرآن","السلاسل","التنزيلات","المفضلة").forEachIndexed{i,t->
                NavigationBarItem(tab==i,{tab=i},icon={Icon(if(i==0)Icons.Default.Home else if(i==1)Icons.Default.MenuBook else if(i==2)Icons.Default.LibraryMusic else if(i==3)Icons.Default.Download else Icons.Default.Favorite,null)},label={Text(t)})
            }}
        }){p->Box(Modifier.padding(p)){when(tab){
            0->Home({tab=1},{tab=2},{group=it},{e->play(player,e);playing=e})
            1->Quran{e->play(player,e);playing=e}
            2->Series{group=it}
            else->Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("قريباً")}
        }}}
        playing?.let{BottomPlayer(it,{player.pause()},{player.play()})}
    }
}
fun play(player:ExoPlayer,e:AudioItem){
    if(e.audioUrl.isBlank()) return
    player.setMediaItem(MediaItem.fromUri(e.audioUrl));player.prepare();player.play()
}
@Composable fun Home(onQ:()->Unit,onS:()->Unit,onG:(String)->Unit,onP:(AudioItem)->Unit){
    val groups=Catalog.lectures.map{it.group}.distinct()
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFF101010)).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("مكتبتي الصوتية",fontSize=28.sp,fontWeight=FontWeight.Bold,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.End)}
        item{Card(Modifier.fillMaxWidth().clickable{onQ()},colors=CardDefaults.cardColors(containerColor=Color(0xFF191919))){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.MenuBook,null,tint=Color(0xFFD5B45A));Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f),horizontalAlignment=Alignment.End){Text("المصحف الكريم — سعد الغامدي",fontWeight=FontWeight.Bold);Text("114 سورة",color=Color(0xFFD5B45A))}}}}
        item{Text("السلاسل",fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.End)}
        items(groups){g->Card(Modifier.fillMaxWidth().clickable{onG(g)},colors=CardDefaults.cardColors(containerColor=Color(0xFF191919))){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.LibraryMusic,null,tint=Color(0xFFD5B45A));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f),horizontalAlignment=Alignment.End){Text(g,fontWeight=FontWeight.Bold);Text("${Catalog.lectures.count{it.group==g}} محاضرة",color=Color(0xFFD5B45A))}}}}
        item{Text("آخر المحاضرات",fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.End)}
        items(Catalog.lectures.take(8)){e->RowItem(e,onP)}
    }
}
@Composable fun Quran(onP:(AudioItem)->Unit){ListScreen("المصحف الكريم — سعد الغامدي",Catalog.quran,onP)}
@Composable fun Series(onG:(String)->Unit){ListScreen("السلاسل",Catalog.lectures.map{it.group}.distinct().map{AudioItem(it,it,it,Catalog.lectures.count{x->x.group==it},"","","")}){onG(it.group)}}
@Composable fun ListScreen(title:String,data:List<AudioItem>,onP:(AudioItem)->Unit){LazyColumn(Modifier.fillMaxSize().background(Color(0xFF101010)).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text(title,fontSize=25.sp,fontWeight=FontWeight.Bold,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.End)};items(data){RowItem(it,onP)}}}
@Composable fun Detail(g:String,onBack:()->Unit,onP:(AudioItem)->Unit){Column(Modifier.fillMaxSize().background(Color(0xFF101010))){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onBack){Icon(Icons.Default.ArrowBack,null)};Spacer(Modifier.weight(1f));Text(g,fontSize=21.sp,fontWeight=FontWeight.Bold)}};LazyColumn(Modifier.padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){items(Catalog.lectures.filter{it.group==g}){RowItem(it,onP)}}}
@Composable fun RowItem(e:AudioItem,onP:(AudioItem)->Unit){Row(Modifier.fillMaxWidth().clickable{onP(e)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){IconButton({onP(e)}){Icon(Icons.Default.PlayArrow,null,tint=Color(0xFFD5B45A))};Spacer(Modifier.weight(1f));Column(horizontalAlignment=Alignment.End){Text("${e.number}. ${e.title}",fontWeight=FontWeight.SemiBold);if(e.group.isNotBlank())Text(e.group,fontSize=11.sp,color=Color.Gray)}}}
@Composable fun BottomPlayer(e:AudioItem,onPause:()->Unit,onPlay:()->Unit){Surface(Modifier.fillMaxWidth(),color=Color(0xFF202020)){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onPause){Icon(Icons.Default.Pause,null)};IconButton(onPlay){Icon(Icons.Default.PlayArrow,null,tint=Color(0xFFD5B45A))};Spacer(Modifier.weight(1f));Text(e.title,fontWeight=FontWeight.Bold)}}}
