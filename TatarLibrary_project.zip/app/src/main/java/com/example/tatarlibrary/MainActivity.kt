package com.example.tatarlibrary

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import java.io.File

private val Black = Color(0xFF101010)
private val Panel = Color(0xFF151515)
private val Panel2 = Color(0xFF303030)
private val Line = Color(0xFFE4E4E4)
private val White = Color(0xFFF7F7F7)
private val Grey = Color(0xFF9B9B9B)
private val Blue = Color(0xFF168BD0)
private val Gold = Color(0xFFD5B06A)
private val Red = Color(0xFFE56D78)

class MainActivity : ComponentActivity() {
    private lateinit var controllerFuture: ListenableFuture<MediaController>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        setContent {
            val controller = rememberController()
            LibraryTheme { LectureLibrary(controller) }
        }
    }

    @Composable
    private fun rememberController(): MediaController? {
        var controller by remember { mutableStateOf<MediaController?>(null) }
        DisposableEffect(Unit) {
            controllerFuture.addListener({
                if (!controllerFuture.isCancelled) controller = controllerFuture.get()
            }, ContextCompat.getMainExecutor(this@MainActivity))
            onDispose { controller?.release() }
        }
        return controller
    }
}

@Composable
private fun LibraryTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Black,
            surface = Panel,
            surfaceVariant = Panel2,
            onBackground = White,
            onSurface = White,
            onSurfaceVariant = Grey,
        ),
        typography = Typography(
            headlineMedium = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
            headlineSmall = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
            titleLarge = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            titleMedium = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        ),
        content = content,
    )
}

private enum class MainTab(val title: String, val icon: ImageVector) {
    HOME("الرئيسية", Icons.Default.Home),
    SERIES("السلاسل", Icons.Default.MenuBook),
    DOWNLOADS("التنزيلات", Icons.Default.Download),
    FAVORITES("المفضلة", Icons.Default.FavoriteBorder),
    MORE("المزيد", Icons.Default.MoreVert),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LectureLibrary(controller: MediaController?) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(MainTab.HOME) }
    var search by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    var playerOpen by remember { mutableStateOf(false) }
    var selectedSeries by remember { mutableStateOf<SeriesInfo?>(null) }
    var sleepMinutes by remember { mutableIntStateOf(0) }
    var sleepOpen by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }

    val favorites = remember { mutableStateMapOf<String, Boolean>() }
    LaunchedEffect(Unit) {
        val p = context.getSharedPreferences("library", Context.MODE_PRIVATE)
        Catalog.episodes.forEach { favorites[it.id] = p.getBoolean("fav_${it.id}", false) }
    }

    LaunchedEffect(controller) {
        while (controller != null) {
            refresh++
            val ep = controller.currentMediaItem?.localConfiguration?.tag as? Episode
            if (ep != null) {
                context.getSharedPreferences("library", Context.MODE_PRIVATE)
                    .edit().putLong("pos_${ep.id}", controller.currentPosition).apply()
            }
            delay(1000)
        }
    }

    LaunchedEffect(controller, sleepMinutes) {
        if (controller != null && sleepMinutes > 0) {
            delay(sleepMinutes * 60_000L)
            controller.pause()
            sleepMinutes = 0
        }
    }

    val current = controller?.currentMediaItem?.localConfiguration?.tag as? Episode
    val playing = controller?.isPlaying == true
    val position = controller?.currentPosition ?: 0L
    val duration = controller?.duration?.takeIf { it > 0 } ?: 0L
    val downloaded = Catalog.episodes.filter { localFile(context, it).exists() }
    val matchingEpisodes = Catalog.episodes.filter {
        search.isBlank() || it.title.contains(search, true) || it.number.toString() == search.trim()
    }

    fun favorite(ep: Episode) {
        val v = !(favorites[ep.id] ?: false)
        favorites[ep.id] = v
        context.getSharedPreferences("library", Context.MODE_PRIVATE).edit()
            .putBoolean("fav_${ep.id}", v).apply()
    }

    fun play(ep: Episode) = playEpisode(context, controller, ep)

    if (selectedSeries != null) {
        SeriesDetails(
            series = selectedSeries!!,
            favorites = favorites,
            onBack = { selectedSeries = null },
            onPlay = ::play,
            onFavorite = ::favorite,
        )
        return
    }

    Scaffold(
        containerColor = Black,
        topBar = {
            if (searchOpen) {
                TopAppBar(
                    navigationIcon = { IconButton(onClick = { searchOpen = false; search = "" }) { Icon(Icons.Default.ArrowBack, "رجوع") } },
                    title = {
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            placeholder = { Text("بحث") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            shape = RoundedCornerShape(28.dp),
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Black),
                )
            } else {
                TopAppBar(
                    title = {
                        Text(
                            when (tab) {
                                MainTab.HOME -> "المحاضرات"
                                MainTab.SERIES -> "السلاسل"
                                MainTab.DOWNLOADS -> "التنزيلات"
                                MainTab.FAVORITES -> "المفضلة"
                                MainTab.MORE -> "المزيد"
                            },
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                        )
                    },
                    actions = {
                        IconButton(onClick = { searchOpen = true }) { Icon(Icons.Default.Search, "بحث") }
                        IconButton(onClick = { sleepOpen = true }) { Icon(Icons.Default.Timer, "مؤقت النوم") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Black),
                )
            }
        },
        bottomBar = {
            Column {
                AnimatedVisibility(
                    visible = current != null,
                    enter = slideInVertically { it } + fadeIn(),
                    exit = slideOutVertically { it } + fadeOut(),
                ) {
                    if (current != null) {
                        MiniPlayer(current, playing, position, duration,
                            onOpen = { playerOpen = true },
                            onPlayPause = { if (playing) controller?.pause() else controller?.play() })
                    }
                }
                NavigationBar(containerColor = Color(0xFF111111), tonalElevation = 0.dp) {
                    MainTab.values().forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(item.icon, null, modifier = Modifier.size(25.dp)) },
                            label = { Text(item.title, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = White,
                                selectedTextColor = White,
                                indicatorColor = Color.Transparent,
                                unselectedIconColor = Grey,
                                unselectedTextColor = Grey,
                            )
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                MainTab.HOME -> HomeScreen(current, playing, position, duration, downloaded.size, favorites, ::play, ::favorite, { playerOpen = true })
                MainTab.SERIES -> SeriesList(search.ifBlank { null }, favorites, { selectedSeries = it }, ::play, ::favorite)
                MainTab.DOWNLOADS -> DownloadsScreen(downloaded, ::play, context, refresh)
                MainTab.FAVORITES -> FavoritesScreen(matchingEpisodes, favorites, ::play, ::favorite)
                MainTab.MORE -> MoreScreen(downloaded.size, favorites.values.count { it })
            }
        }
    }

    if (playerOpen && current != null) {
        FullPlayer(
            controller = controller,
            ep = current,
            playing = playing,
            position = position,
            duration = duration,
            sleepMinutes = sleepMinutes,
            favorite = favorites[current.id] == true,
            onClose = { playerOpen = false },
            onFavorite = { favorite(current) },
            onSleep = { sleepOpen = true },
        )
    }

    if (sleepOpen) {
        SleepDialog(sleepMinutes, { sleepMinutes = it; sleepOpen = false }, { sleepOpen = false })
    }
}

@Composable
private fun HomeScreen(
    current: Episode?, playing: Boolean, position: Long, duration: Long, downloaded: Int,
    favorites: Map<String, Boolean>, onPlay: (Episode) -> Unit, onFavorite: (Episode) -> Unit, onOpenPlayer: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { HeroSeries(onPlay) }
        if (current != null) item { ContinueListening(current, playing, position, duration, onOpenPlayer) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HomeStat("${Catalog.series.size}", "سلاسل", Icons.Default.Collections, Modifier.weight(1f))
                HomeStat("${Catalog.episodes.size}", "محاضرة", Icons.Default.Headphones, Modifier.weight(1f))
                HomeStat("$downloaded", "تنزيلات", Icons.Default.DownloadDone, Modifier.weight(1f))
            }
        }
        item { SectionHeader("أحدث المحاضرات", "عرض الكل") }
        items(Catalog.episodes.take(8), key = { it.id }) { ep ->
            EpisodeLine(ep, favorites[ep.id] == true, onPlay, onFavorite)
        }
    }
}

@Composable
private fun HeroSeries(onPlay: (Episode) -> Unit) {
    val series = Catalog.series.first()
    Box(
        Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(4.dp)).background(
            Brush.verticalGradient(listOf(Color(0xFF555555), Color(0xFF242424), Color(0xFF151515)))
        )
    ) {
        Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.End) {
            Text("سلسلة مميزة", color = Gold, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(series.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.End)
            Text(series.author, color = White, fontSize = 15.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { onPlay(series.episodes.first()) }, border = BorderStroke(2.dp, White), shape = RoundedCornerShape(24.dp)) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(5.dp))
                Text("استمع الآن", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ContinueListening(ep: Episode, playing: Boolean, position: Long, duration: Long, onOpen: () -> Unit) {
    val progress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    Surface(Modifier.fillMaxWidth().clickable { onOpen() }, color = Panel, shape = RoundedCornerShape(4.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Cover(58)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("متابعة الاستماع", color = Blue, fontWeight = FontWeight.Bold)
                    Text(ep.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                    Text("الحلقة ${ep.number}", color = Grey, fontSize = 12.sp)
                }
                FilledIconButton(onClick = onOpen, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Panel2)) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                }
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(3.dp), trackColor = Panel2)
        }
    }
}

@Composable
private fun HomeStat(value: String, label: String, icon: ImageVector, modifier: Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(4.dp)) {
        Column(Modifier.padding(vertical = 11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(21.dp))
            Text(value, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            Text(label, color = Grey, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.weight(1f))
        Text(action, color = Blue, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SeriesList(query: String?, favorites: Map<String, Boolean>, onOpen: (SeriesInfo) -> Unit, onPlay: (Episode) -> Unit, onFavorite: (Episode) -> Unit) {
    val list = Catalog.series.filter { query.isNullOrBlank() || it.title.contains(query, true) || it.author.contains(query, true) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("السلاسل الصوتية", color = Grey, fontSize = 13.sp) }
        items(list, key = { it.id }) { series ->
            SeriesCard(series, favorites, onOpen, onPlay, onFavorite)
        }
    }
}

@Composable
private fun SeriesCard(series: SeriesInfo, favorites: Map<String, Boolean>, onOpen: (SeriesInfo) -> Unit, onPlay: (Episode) -> Unit, onFavorite: (Episode) -> Unit) {
    Surface(Modifier.fillMaxWidth(), color = Panel, shape = RoundedCornerShape(4.dp)) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(series) }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(72)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(series.title, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.End)
                    Text(series.author, color = Grey)
                    Spacer(Modifier.height(4.dp))
                    Text("${series.episodeCount} محاضرة  •  مداد", color = Gold, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronLeft, null, tint = Grey)
            }
            Divider(color = Line, thickness = 1.dp)
            val preview = series.episodes.take(2)
            preview.forEach { ep ->
                EpisodeLine(ep, favorites[ep.id] == true, onPlay, onFavorite, compact = true)
            }
        }
    }
}

@Composable
private fun SeriesDetails(series: SeriesInfo, favorites: Map<String, Boolean>, onBack: () -> Unit, onPlay: (Episode) -> Unit, onFavorite: (Episode) -> Unit) {
    Scaffold(
        containerColor = Black,
        topBar = {
            TopAppBar(
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, "رجوع") } },
                title = { Text(series.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.ExtraBold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Black),
            )
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Cover(86)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                            Text(series.title, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.End)
                            Text(series.author, color = Grey)
                            Text("${series.episodeCount} حلقة", color = Gold, fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedButton(onClick = { onPlay(series.episodes.first()) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), border = BorderStroke(1.5.dp, White)) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("تشغيل السلسلة")
                    }
                }
                Divider(color = Panel2, thickness = 8.dp)
                SearchPill("بحث داخل السلسلة")
            }
            items(series.episodes, key = { it.id }) { ep ->
                EpisodeLine(ep, favorites[ep.id] == true, onPlay, onFavorite, showDownload = true)
            }
        }
    }
}

@Composable
private fun SearchPill(text: String) {
    Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), color = Panel2, shape = RoundedCornerShape(26.dp), border = BorderStroke(1.dp, Grey)) {
        Text(text, modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp), color = White, textAlign = TextAlign.End)
    }
}

@Composable
private fun EpisodeLine(ep: Episode, favorite: Boolean, onPlay: (Episode) -> Unit, onFavorite: (Episode) -> Unit, compact: Boolean = false, showDownload: Boolean = true) {
    val context = LocalContext.current
    var downloaded by remember(ep.id) { mutableStateOf(localFile(context, ep).exists()) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = if (compact) 6.dp else 9.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onPlay(ep) }, modifier = Modifier.size(42.dp)) {
                Icon(Icons.Default.PlayCircleOutline, null, tint = White, modifier = Modifier.size(34.dp))
            }
            Spacer(Modifier.width(4.dp))
            Box(Modifier.size(34.dp).clip(CircleShape).background(Panel2), contentAlignment = Alignment.Center) {
                Text(ep.number.toString(), color = Grey, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text(ep.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End)
                Text(if (ep.duration.isBlank()) "محاضرة صوتية" else ep.duration, color = Grey, fontSize = 11.sp, textAlign = TextAlign.End)
            }
            IconButton(onClick = { onFavorite(ep) }, modifier = Modifier.size(40.dp)) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Red else White)
            }
            if (showDownload) {
                IconButton(onClick = {
                    if (downloaded) {
                        localFile(context, ep).delete()
                        downloaded = false
                    } else if (ep.url.isNotBlank()) {
                        enqueueDownload(context, ep)
                    }
                }, modifier = Modifier.size(40.dp)) {
                    Icon(if (downloaded) Icons.Default.DownloadDone else Icons.Default.Download, null, tint = if (downloaded) Blue else Grey)
                }
            }
        }
        Divider(color = Line, thickness = 1.dp, modifier = Modifier.padding(start = 12.dp, end = 12.dp))
    }
}

@Composable
private fun DownloadsScreen(downloaded: List<Episode>, onPlay: (Episode) -> Unit, context: Context, refresh: Int) {
    if (downloaded.isEmpty()) {
        EmptyState("لا توجد تنزيلات", "المحاضرات التي تحفظها للاستماع دون إنترنت ستظهر هنا.", Icons.Default.Download)
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item { SectionHeader("تحميلاتك", "${downloaded.size} ملف") }
        item { Spacer(Modifier.height(8.dp)) }
        items(downloaded, key = { it.id }) { ep -> EpisodeLine(ep, false, onPlay, {}, showDownload = true) }
    }
}

@Composable
private fun FavoritesScreen(episodes: List<Episode>, favorites: Map<String, Boolean>, onPlay: (Episode) -> Unit, onFavorite: (Episode) -> Unit) {
    val list = episodes.filter { favorites[it.id] == true }
    if (list.isEmpty()) {
        EmptyState("المفضلة فارغة", "اضغط على القلب بجانب أي محاضرة لإضافتها هنا.", Icons.Default.FavoriteBorder)
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item { SectionHeader("محاضراتك المفضلة", "${list.size}") }
        item { Spacer(Modifier.height(8.dp)) }
        items(list, key = { it.id }) { ep -> EpisodeLine(ep, true, onPlay, onFavorite) }
    }
}

@Composable
private fun MoreScreen(downloaded: Int, favorites: Int) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("المزيد", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold) }
        item { MoreRow(Icons.Default.Info, "عن المكتبة", "مكتبة شخصية للاستماع إلى السلاسل والمحاضرات") }
        item { MoreRow(Icons.Default.DarkMode, "الوضع الداكن", "مفعّل") }
        item { MoreRow(Icons.Default.DownloadDone, "المحفوظ محلياً", "$downloaded ملف") }
        item { MoreRow(Icons.Default.Favorite, "المفضلة", "$favorites محاضرة") }
    }
}

@Composable
private fun MoreRow(icon: ImageVector, title: String, subtitle: String) {
    Surface(Modifier.fillMaxWidth(), color = Panel, shape = RoundedCornerShape(4.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Grey, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronLeft, null, tint = Grey)
        }
    }
}

@Composable
private fun MiniPlayer(ep: Episode, playing: Boolean, position: Long, duration: Long, onOpen: () -> Unit, onPlayPause: () -> Unit) {
    val progress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    Surface(Modifier.fillMaxWidth().clickable { onOpen() }, color = Color(0xFF171717)) {
        Column {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(45)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(ep.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${ep.number} • ${Catalog.series.firstOrNull { it.id == ep.seriesId }?.title ?: "محاضرة"}", color = Grey, fontSize = 10.sp)
                }
                IconButton(onClick = onPlayPause) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = White) }
            }
            LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth().height(2.dp), trackColor = Panel2)
        }
    }
}

@Composable
private fun FullPlayer(controller: MediaController?, ep: Episode, playing: Boolean, position: Long, duration: Long, sleepMinutes: Int, favorite: Boolean, onClose: () -> Unit, onFavorite: () -> Unit, onSleep: () -> Unit) {
    val progress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    Surface(Modifier.fillMaxSize(), color = Black) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF606060), Color(0xFF2D2D2D), Black)))) {
            Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, "إغلاق", tint = White, modifier = Modifier.size(32.dp)) }
                    Spacer(Modifier.weight(1f))
                    Text("المشغّل", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onSleep) { Icon(Icons.Default.Timer, "مؤقت", tint = if (sleepMinutes > 0) Gold else White) }
                }
                Spacer(Modifier.height(28.dp))
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Cover(285)
                }
                Text(ep.title, Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(5.dp))
                Text("${Catalog.series.firstOrNull { it.id == ep.seriesId }?.author ?: ""} • الحلقة ${ep.number}", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = White)
                Spacer(Modifier.height(20.dp))
                Slider(value = progress, onValueChange = { if (duration > 0) controller?.seekTo((it * duration).toLong()) }, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(position), color = White, fontSize = 12.sp)
                    Text(formatTime(duration), color = White, fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Red else White, modifier = Modifier.size(29.dp)) }
                    IconButton(onClick = { controller?.seekBack() }) { Icon(Icons.Default.Replay10, null, tint = White, modifier = Modifier.size(38.dp)) }
                    FilledIconButton(onClick = { if (playing) controller?.pause() else controller?.play() }, modifier = Modifier.size(76.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = White, contentColor = Black)) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(42.dp))
                    }
                    IconButton(onClick = { controller?.seekForward() }) { Icon(Icons.Default.Forward10, null, tint = White, modifier = Modifier.size(38.dp)) }
                    IconButton(onClick = { controller?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(34.dp)) }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    PlayerAction(Icons.Default.Download, "تنزيل")
                    PlayerAction(Icons.Default.PlaylistAdd, "القائمة")
                    PlayerAction(Icons.Default.Share, "مشاركة")
                    PlayerAction(Icons.Default.Speed, if (sleepMinutes > 0) "$sleepMinutes د" else "1.0x")
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun PlayerAction(icon: ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = White, modifier = Modifier.size(24.dp))
        Text(label, color = White, fontSize = 11.sp)
    }
}

@Composable
private fun SleepDialog(selected: Int, onSelected: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مؤقت النوم") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                listOf(15, 30, 45, 60, 90).forEach { min ->
                    Row(Modifier.fillMaxWidth().clickable { onSelected(min) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected == min, { onSelected(min) })
                        Spacer(Modifier.width(8.dp))
                        Text("بعد $min دقيقة")
                    }
                }
                if (selected > 0) TextButton(onClick = { onSelected(0) }) { Text("إلغاء المؤقت") }
            }
        },
        confirmButton = {},
    )
}

@Composable
private fun EmptyState(title: String, text: String, icon: ImageVector) {
    Box(Modifier.fillMaxSize().padding(30.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(78.dp).clip(CircleShape).background(Panel2), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Blue, modifier = Modifier.size(35.dp)) }
            Spacer(Modifier.height(15.dp))
            Text(title, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(7.dp))
            Text(text, color = Grey, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun Cover(size: Int) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size * .10f).dp)).background(
            Brush.linearGradient(listOf(Color(0xFF5A5A5A), Color(0xFF292929), Color(0xFF151515)))
        ),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Headphones, null, tint = White, modifier = Modifier.size((size * .34f).dp))
            Text("مكتبة", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = (size * .11f).coerceAtLeast(9f).sp)
        }
    }
}

private fun playEpisode(context: Context, controller: MediaController?, episode: Episode) {
    controller ?: return
    val items = Catalog.episodes.mapNotNull { ep ->
        val file = localFile(context, ep)
        val uri = when {
            file.exists() -> Uri.fromFile(file)
            ep.url.isNotBlank() -> Uri.parse(ep.url)
            else -> null
        } ?: return@mapNotNull null
        MediaItem.Builder().setMediaId(ep.id).setUri(uri).setTag(ep).build()
    }
    val index = items.indexOfFirst { it.mediaId == episode.id }
    if (index < 0) return
    controller.setMediaItems(items, index, savedPosition(context, episode))
    controller.prepare()
    controller.play()
}

private fun savedPosition(context: Context, ep: Episode): Long =
    context.getSharedPreferences("library", Context.MODE_PRIVATE).getLong("pos_${ep.id}", 0L)

private fun localFile(context: Context, ep: Episode): File =
    File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "tatar/${ep.fileName}")

private fun enqueueDownload(context: Context, ep: Episode) {
    if (ep.url.isBlank()) return
    val request = DownloadManager.Request(Uri.parse(ep.url))
        .setTitle("${ep.number}. ${ep.title}")
        .setDescription("حفظ في مكتبتي الصوتية")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setAllowedOverMetered(true)
        .setAllowedOverRoaming(true)
        .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MUSIC, "tatar/${ep.fileName}")
    (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
}

private fun formatTime(ms: Long): String {
    val total = ms.coerceAtLeast(0L) / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
