package com.example.tatarlibrary

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var controllerFuture: ListenableFuture<MediaController>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()

        setContent {
            val controller = rememberController()
            TatarApp(controller)
        }
    }

    @Composable
    private fun rememberController(): MediaController? {
        var controller by remember { mutableStateOf<MediaController?>(null) }
        DisposableEffect(Unit) {
            val listener = Runnable {
                if (controllerFuture.isDone && !controllerFuture.isCancelled) {
                    controller = controllerFuture.get()
                }
            }
            controllerFuture.addListener(listener, ContextCompat.getMainExecutor(this@MainActivity))
            onDispose { controller?.release() }
        }
        return controller
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TatarApp(controller: MediaController?) {
    var refresh by remember { mutableIntStateOf(0) }
    var currentIndex by remember { mutableIntStateOf(-1) }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }

    LaunchedEffect(controller) {
        if (controller == null) return@LaunchedEffect
        while (true) {
            currentIndex = controller.currentMediaItemIndex
            isPlaying = controller.isPlaying
            position = controller.currentPosition.coerceAtLeast(0)
            duration = controller.duration.coerceAtLeast(0)
            refresh++
            delay(700)
        }
    }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("مكتبتي الصوتية") },
                colors = TopAppBarDefaults.smallTopAppBarColors()
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)
        ) {
            Text("سلسلة التتار من البداية إلى عين جالوت", style = MaterialTheme.typography.titleLarge)
            Text("12 حلقة • تشغيل مباشر + تنزيل اختياري", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(10.dp))

            if (controller != null && currentIndex >= 0 && currentIndex < Catalog.episodes.size) {
                val ep = Catalog.episodes[currentIndex]
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("يعمل الآن: ${ep.number}. ${ep.title}", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = {
                                if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { controller.seekToPreviousMediaItem() }) {
                                Icon(Icons.Default.SkipPrevious, "السابق")
                            }
                            IconButton(onClick = { controller.seekBack() }) {
                                Icon(Icons.Default.Replay10, "ترجيع")
                            }
                            IconButton(onClick = { if (isPlaying) controller.pause() else controller.play() }) {
                                Icon(
                                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    "تشغيل/إيقاف"
                                )
                            }
                            IconButton(onClick = { controller.seekForward() }) {
                                Icon(Icons.Default.Forward10, "تقديم")
                            }
                            IconButton(onClick = { controller.seekToNextMediaItem() }) {
                                Icon(Icons.Default.SkipNext, "التالي")
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(Catalog.episodes, key = { it.number }) { ep ->
                    EpisodeCard(
                        episode = ep,
                        controller = controller,
                        onChanged = { refresh++ }
                    )
                }
            }
        }
    }
}

@Composable
fun EpisodeCard(
    episode: Episode,
    controller: MediaController?,
    onChanged: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val localFile = remember(episode.fileName) {
        File(
            context.getExternalFilesDir(Environment.DIRECTORY_MUSIC),
            "tatar/${episode.fileName}"
        )
    }
    var exists by remember { mutableStateOf(localFile.exists()) }

    LaunchedEffect(Unit) {
        while (true) {
            exists = localFile.exists()
            delay(1200)
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("${episode.number}. ${episode.title}", style = MaterialTheme.typography.titleMedium)
            Text(episode.duration, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    enabled = controller != null,
                    onClick = {
                        controller ?: return@Button
                        val mediaItems = Catalog.episodes.map { e ->
                            val f = File(
                                context.getExternalFilesDir(Environment.DIRECTORY_MUSIC),
                                "tatar/${e.fileName}"
                            )
                            MediaItem.Builder()
                                .setMediaId(e.number.toString())
                                .setUri(if (f.exists()) Uri.fromFile(f) else Uri.parse(e.url))
                                .setTag(e)
                                .build()
                        }
                        controller.setMediaItems(mediaItems, episode.number - 1, 0L)
                        controller.prepare()
                        controller.play()
                    }
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(5.dp))
                    Text("تشغيل")
                }

                if (exists) {
                    IconButton(onClick = {
                        if (localFile.delete()) {
                            exists = false
                            onChanged()
                        }
                    }) {
                        Icon(Icons.Default.Delete, "حذف التنزيل")
                    }
                } else {
                    IconButton(onClick = {
                        localFile.parentFile?.mkdirs()
                        val request = DownloadManager.Request(Uri.parse(episode.url))
                            .setTitle("${episode.number}. ${episode.title}")
                            .setDescription("تنزيل للمشاهدة/الاستماع بدون إنترنت")
                            .setNotificationVisibility(
                                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                            )
                            .setAllowedOverMetered(true)
                            .setAllowedOverRoaming(true)
                            .setDestinationInExternalFilesDir(
                                context,
                                Environment.DIRECTORY_MUSIC,
                                "tatar/${episode.fileName}"
                            )
                        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                        dm.enqueue(request)
                    }) {
                        Icon(Icons.Default.Download, "تنزيل")
                    }
                }

                Text(if (exists) "محفوظ أوفلاين" else "أونلاين")
            }
        }
    }
}
