package com.example.tatarlibrary

data class Episode(
    val id: String,
    val seriesId: String,
    val number: Int,
    val title: String,
    val duration: String = "",
    val fileName: String,
    val url: String = ""
)

data class SeriesInfo(
    val id: String,
    val title: String,
    val author: String,
    val sourceUrl: String,
    val episodeCount: Int,
    val episodes: List<Episode>
)

object Catalog {
    private fun ep(series: String, n: Int, title: String) = Episode(
        id = "$series-$n",
        seriesId = series,
        number = n,
        title = title,
        fileName = "${series}_${n.toString().padStart(2, '0')}.mp3"
    )

    val series = listOf(
        SeriesInfo("tatar", "التتار من البداية إلى عين جالوت", "د. راغب السرجاني", "https://midad.com/collection/454060", 12, listOf(
            ep("tatar",1,"بداية القصة"), ep("tatar",2,"الاجتياح: الجزء الأول"), ep("tatar",3,"المتساقطون"), ep("tatar",4,"الاجتياح: الجزء الثاني"), ep("tatar",5,"خطة غزو بغداد"), ep("tatar",6,"سقوط بغداد"), ep("tatar",7,"سقوط سوريا"), ep("tatar",8,"المماليك"), ep("tatar",9,"مباني الأمة"), ep("tatar",10,"قرار الجهاد"), ep("tatar",11,"عين جالوت"), ep("tatar",12,"عين جالوت في الميزان")
        )),
        SeriesInfo("sahaba", "كن صحايباً", "د. راغب السرجاني", "https://midad.com/collection/453820", 10, listOf(
            ep("sahaba",1,"جيلٌ فريد"), ep("sahaba",2,"القابضون على الجمر"), ep("sahaba",3,"الصحابة والإخلاص"), ep("sahaba",4,"الصحابة والعلم"), ep("sahaba",5,"الصحابة والعمل"), ep("sahaba",6,"الصحابة والدنيا"), ep("sahaba",7,"الصحابة والجنة"), ep("sahaba",8,"الصحابة واتباع الرسول"), ep("sahaba",9,"الصحابة والأخوة"), ep("sahaba",10,"صناعة الرجال")
        )),
        SeriesInfo("makkah", "في ظلال السيرة - العهد المكي", "د. راغب السرجاني", "https://midad.com/collection/454032", 14, listOf(
            ep("makkah",1,"السيرة وبناء الأمة"), ep("makkah",2,"من الظلمات إلى النور"), ep("makkah",3,"من هنا بدأ الإسلام"), ep("makkah",4,"بدء الوحي"), ep("makkah",5,"الدعوة سرا"), ep("makkah",6,"الدعوة جهرا"), ep("makkah",7,"تربية الثبات"), ep("makkah",8,"هجرة الحبشة الأولى"), ep("makkah",9,"هجرة الحبشة الثانية"), ep("makkah",10,"إسلام عمر رضي الله عنه"), ep("makkah",11,"عام الحزن"), ep("makkah",12,"بيعة العقبة الأولى"), ep("makkah",13,"بيعة العاقبة الثانية"), ep("makkah",14,"الهجرة إلى المدينة")
        )),
        SeriesInfo("madinah", "في ظلال السيرة - العهد المدني", "د. راغب السرجاني", "https://midad.com/collection/453992", 31, listOf(
            ep("madinah",1,"قيام الدولة الإسلامية"), ep("madinah",2,"مجتمع المدينة"), ep("madinah",3,"المشركون والدولة الإسلامية"), ep("madinah",4,"اليهود والدولة الإسلامية"), ep("madinah",5,"الطريق إلى بدر"), ep("madinah",6,"أهل بدر"), ep("madinah",7,"يوم بدر"), ep("madinah",8,"نصر بدر"), ep("madinah",9,"مابعد بدر"), ep("madinah",10,"الطريق إلى أحد"), ep("madinah",11,"يوم أحد"), ep("madinah",12,"الخروج من مصيبة أحد"), ep("madinah",13,"الطريق إلى الأحزاب"), ep("madinah",14,"الأحزاب"), ep("madinah",15,"المسلمون بعد الأحزاب"), ep("madinah",16,"الطريق إلى الحديبية"), ep("madinah",17,"صلح الحديبية"), ep("madinah",18,"ما بعد الحديبية"), ep("madinah",19,"عالمية الإسلام"), ep("madinah",20,"فتح خيبر"), ep("madinah",21,"قوة الإسلام"), ep("madinah",22,"نصر مؤتة"), ep("madinah",23,"الطريق إلى مكة"), ep("madinah",24,"فتح مكة"), ep("madinah",25,"إسلام مكة"), ep("madinah",26,"يوم حنين"), ep("madinah",27,"إسلام هوزان"), ep("madinah",28,"غزوة تبوك"), ep("madinah",29,"ما بعد تبوك"), ep("madinah",30,"حجة الوداع"), ep("madinah",31,"خاتمة السيرة")
        )),
        SeriesInfo("andalus", "الأندلس من الفتح إلى السقوط", "د. راغب السرجاني", "https://midad.com/collection/453956", 12, listOf(
            ep("andalus",1,"الطريق إلى الأندلس"), ep("andalus",2,"عهد الفتح الاسلامي"), ep("andalus",3,"عهد الولاة"), ep("andalus",4,"عبدالرحمن الداخل صقر قريش"), ep("andalus",5,"الإمارة الأموية"), ep("andalus",6,"الخلافة الأموية"), ep("andalus",7,"عهد الدولة العامرية والفتنة"), ep("andalus",8,"عهد ملوك الطوائف"), ep("andalus",9,"دولة المرابطين"), ep("andalus",10,"بين المرابطين والموحدين"), ep("andalus",11,"دولة الموحدين"), ep("andalus",12,"سقوط الأندلس")
        )),
        SeriesInfo("palestine", "فلسطين حتى لا تكون أندلسًا أخرى", "د. راغب السرجاني", "https://midad.com/collection/454082", 11, listOf(
            ep("palestine",1,"المؤامرة"), ep("palestine",2,"فلسطين إسلامية"), ep("palestine",3,"مفاهيم خاطئة"), ep("palestine",4,"إسرائيل الكبرى"), ep("palestine",5,"اغتيال الخلافة"), ep("palestine",6,"تهويد الخلافة"), ep("palestine",7,"جريمة التقسيم"), ep("palestine",8,"حرب 1948"), ep("palestine",9,"أمة لن تموت"), ep("palestine",10,"الجهاد بالمال"), ep("palestine",11,"الدعاء")
        ))
    )

    val episodes: List<Episode> = series.flatMap { it.episodes }
}
