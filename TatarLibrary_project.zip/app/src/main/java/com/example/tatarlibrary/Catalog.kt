package com.example.tatarlibrary

data class Episode(
    val number: Int,
    val title: String,
    val duration: String,
    val fileName: String,
    val url: String
)

object Catalog {
    private const val BASE =
        "https://archive.org/download/Tatar-series-from-start-to-eye-Goliath_uP_bY_mUSLEm/"

    val episodes = listOf(
        Episode(1, "بداية القصة", "39:25", "01.mp3", BASE + "01.mp3"),
        Episode(2, "الاجتياح", "1:05:44", "02.mp3", BASE + "02.mp3"),
        Episode(3, "المتساقطون", "1:09:47", "03.mp3", BASE + "03.mp3"),
        Episode(4, "خطة غزو العراق", "1:07:20", "04.mp3", BASE + "04.mp3"),
        Episode(5, "سقوط بغداد", "1:10:30", "05.mp3", BASE + "05.mp3"),
        Episode(6, "سقوط سوريا", "1:11:07", "06.mp3", BASE + "06.mp3"),
        Episode(7, "المماليك", "1:08:54", "07.mp3", BASE + "07.mp3"),
        Episode(8, "قطز وبناء الأمة", "1:09:05", "08.mp3", BASE + "08.mp3"),
        Episode(9, "قرار الجهاد", "1:08:03", "09.mp3", BASE + "09.mp3"),
        Episode(10, "عين جالوت", "1:07:42", "10.mp3", BASE + "10.mp3"),
        Episode(11, "عين جالوت في الميزان", "—", "11.mp3", BASE + "11.mp3"),
        Episode(12, "بغداد بين سقوطين", "—", "12.mp3", BASE + "12.mp3"),
    )
}
