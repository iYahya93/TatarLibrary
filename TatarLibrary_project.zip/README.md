# TatarLibrary — fresh rebuild
114 Quran surahs (Saad Al-Ghamdi) using the supplied direct MP3 URLs.
90 Midad lecture records across 6 supplied series, preserving the supplied Midad lesson URLs.
No guessed lecture MP3 URLs are inserted.
