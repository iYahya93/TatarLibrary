# TatarLibrary — أول نسخة Android

تطبيق شخصي لمكتبة صوتية، مبني على Kotlin + Jetpack Compose + Media3.

## الموجود في النسخة الأولى
- سلسلة «التتار من البداية إلى عين جالوت» — 12 حلقة.
- تشغيل مباشر من Internet Archive.
- زر تنزيل مستقل لكل حلقة.
- إذا نُزّلت الحلقة، يستخدم التطبيق الملف المحلي تلقائياً.
- تشغيل بالخلفية عبر MediaSessionService.
- تحكم من شاشة القفل / Bluetooth / الإشعارات.
- تقديم وترجيع 15 ثانية.
- انتقال للسابق/التالي عند وجود قائمة تشغيل.
- حفظ موضع التشغيل داخل Media3.
- الملفات المنزلة تبقى داخل مساحة التطبيق ولا تحتاج صلاحية تخزين عامة.

## المصدر
العنصر:
https://archive.org/details/Tatar-series-from-start-to-eye-Goliath_uP_bY_mUSLEm

الروابط المستخدمة في الكتالوج هي ملفات MP3 المباشرة داخل نفس العنصر:
https://archive.org/download/Tatar-series-from-start-to-eye-Goliath_uP_bY_mUSLEm/01.mp3
... إلى 12.mp3

> ملاحظة: يجب التأكد من حقوق/شروط إعادة استخدام الملفات قبل توزيع التطبيق أو الملفات خارج الاستخدام الشخصي.

## البناء
افتح مجلد المشروع في Android Studio حديث، ثم Sync وRun.

المشروع يستخدم:
- compileSdk 37
- Jetpack Compose BOM 2026.08.00
- Media3 1.11.0

لم أضع Gradle Wrapper داخل الملف المضغوط، لذلك Android Studio يمكنه إنشاء/استخدام Gradle المناسب عند فتح المشروع.
